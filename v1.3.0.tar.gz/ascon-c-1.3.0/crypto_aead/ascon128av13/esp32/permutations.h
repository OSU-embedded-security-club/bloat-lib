#ifndef PERMUTATIONS_H_
#define PERMUTATIONS_H_

#include "ascon.h"

void P(ascon_state_t *p, uint8_t round_const);

#endif  // PERMUTATIONS_H_
