#include "constants.h"

#if !ASCON_UNROLL_LOOPS

const uint64_t constants[] = {RC0, RC1, RC2, RC3, RC4, RC5,
                              RC6, RC7, RC8, RC9, RCa, RCb};

#endif
